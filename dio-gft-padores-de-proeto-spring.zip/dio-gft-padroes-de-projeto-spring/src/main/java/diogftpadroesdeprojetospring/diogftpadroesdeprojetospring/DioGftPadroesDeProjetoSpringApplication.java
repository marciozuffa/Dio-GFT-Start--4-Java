package diogftpadroesdeprojetospring.diogftpadroesdeprojetospring;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class DioGftPadroesDeProjetoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DioGftPadroesDeProjetoSpringApplication.class, args);
	}

}
