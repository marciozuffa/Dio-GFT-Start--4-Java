package diogftpadroesdeprojetospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioGftPadroesDeProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
